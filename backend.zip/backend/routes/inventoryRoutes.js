// axeyo-backend/routes/inventoryRoutes.js

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Inventory = require('../models/Inventory');

// @route   GET /api/inventory - Get all items
router.get('/', auth, async (req, res) => {
    try {
        const items = await Inventory.find().sort({ itemName: 1 });
        res.json(items);
    } catch (err) {
        res.status(500).send('Server Error');
    }
});

// @route   POST /api/inventory - Add a new item
router.post('/', auth, async (req, res) => {
    // UPDATED: Destructure all fields being sent from the new frontend modal
    const { 
        itemName, itemColor, itemThickness, itemShape, itemPolish, 
        quantity, unit, rate 
    } = req.body;

    try {
        const newItem = new Inventory({ 
            itemName, 
            itemColor, 
            itemThickness, 
            itemShape, 
            itemPolish, 
            quantity, 
            unit, // Must match the name in the Mongoose Schema
            rate 
        });

        const item = await newItem.save();
        res.status(201).json(item);

    } catch (err) {
        console.error('Inventory Save Error:', err.message);
        
        // Handle Mongoose validation errors (like missing required fields or wrong data type)
        if (err.name === 'ValidationError') {
            return res.status(400).json({ msg: err.message });
        }
        if (err.code === 11000) {
            return res.status(400).json({ msg: 'An item with this name already exists.' });
        }
        res.status(500).send('Server Error');
    }
});

// @route   PUT /api/inventory/:id - Update item
router.put('/:id', auth, async (req, res) => {
    try {
        let item = await Inventory.findById(req.params.id);

        if (!item) return res.status(404).json({ msg: 'Item not found' });

        // UPDATED: Use spread operator to allow all fields in req.body (including new ones) to update
        item = await Inventory.findByIdAndUpdate(
            req.params.id,
            { $set: { ...req.body, lastUpdated: Date.now() } },
            { new: true, runValidators: true } // runValidators ensures new fields meet schema rules on update
        );

        res.json(item);

    } catch (err) {
        console.error('Inventory Update Error:', err.message);

        if (err.name === 'ValidationError') {
            return res.status(400).json({ msg: err.message });
        }
        res.status(500).send('Server Error');
    }
});

// @route   DELETE /api/inventory/:id - Delete item
router.delete('/:id', auth, async (req, res) => {
    try {
        const result = await Inventory.findByIdAndDelete(req.params.id);
        if (!result) return res.status(404).json({ msg: 'Item not found' });
        
        res.json({ msg: 'Item removed' });
        
    } catch (err) {
        res.status(500).send('Server Error');
    }
});

module.exports = router;