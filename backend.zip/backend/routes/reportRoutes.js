// axeyo-backend/routes/reportRoutes.js

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Inventory = require('../models/Inventory');
const Invoice = require('../models/Invoice');

// Utility to get start of day
const getTodayStart = () => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
};

// @route   GET /api/reports/dashboard-summary
router.get('/dashboard-summary', auth, async (req, res) => {
    try {
        const todayStart = getTodayStart();

        // 1. Total Stock & Low Stock Items
        const totalStockResult = await Inventory.aggregate([
            { $group: { _id: null, totalQuantity: { $sum: '$quantity' } } }
        ]);
        const lowStockItems = await Inventory.countDocuments({ quantity: { $lt: 50 } });

        // 2. Today's Sales & Total Invoices
        const todaysSalesResult = await Invoice.aggregate([
            { $match: { invoiceDate: { $gte: todayStart } } },
            { $group: { _id: null, totalSales: { $sum: '$grandTotal' }, count: { $sum: 1 } } }
        ]);
        
        // 3. Monthly Sales Trend (Last 6 months)
        const sixMonthsAgo = new Date();
        sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
        sixMonthsAgo.setDate(1); 

        const monthlySales = await Invoice.aggregate([
            { $match: { invoiceDate: { $gte: sixMonthsAgo } } },
            { $group: {
                _id: { month: { $month: '$invoiceDate' }, year: { $year: '$invoiceDate' } },
                revenue: { $sum: '$grandTotal' }
            }},
            { $sort: { '_id.year': 1, '_id.month': 1 } }
        ]);

        const formatMonthlySales = monthlySales.map(d => ({
            month: new Date(d._id.year, d._id.month - 1).toLocaleString('default', { month: 'short' }),
            revenue: d.revenue
        }));

        res.json({
            summary: {
                totalStock: totalStockResult[0]?.totalQuantity || 0,
                todaysSales: todaysSalesResult[0]?.totalSales || 0,
                totalInvoices: todaysSalesResult[0]?.count || 0,
                lowStockItems: lowStockItems || 0,
            },
            monthlySales: formatMonthlySales
        });

    } catch (err) {
        res.status(500).json({ msg: 'Server Error in generating dashboard summary.' });
    }
});

// @route   GET /api/reports/:reportType
router.get('/:reportType', auth, async (req, res) => {
    const { reportType } = req.params;
    const { start, end } = req.query;
    
    const startDate = start ? new Date(start) : new Date(0);
    const endDate = end ? new Date(end) : new Date();

    try {
        let kpis = { totalRevenue: 0, itemsSold: 0, stockValue: 0, topItem: 'N/A' };
        let reportData = [];

        // Calculate Stock Value for KPI Card
        const stockValueResult = await Inventory.aggregate([
            { $group: { _id: null, value: { $sum: { $multiply: ['$quantity', '$rate'] } } } }
        ]);
        kpis.stockValue = stockValueResult[0]?.value || 0;

        // Sales Report Logic
        if (reportType === 'sales-month') {
            const salesResults = await Invoice.aggregate([
                { $match: { invoiceDate: { $gte: startDate, $lte: endDate } } },
                { $group: {
                    _id: { $dateToString: { format: '%Y-%m-%d', date: '$invoiceDate' } },
                    revenue: { $sum: '$grandTotal' }
                }},
                { $sort: { '_id': 1 } }
            ]);
            
            reportData = salesResults.map(d => ({ label: d._id, revenue: d.revenue }));
            kpis.totalRevenue = reportData.reduce((acc, curr) => acc + curr.revenue, 0);
            kpis.itemsSold = reportData.length > 0 ? 500 : 0; // Placeholder until line item aggregation is added

        } else if (reportType === 'inventory-value') {
            // Inventory composition based on type
            reportData = await Inventory.aggregate([
                { $group: {
                    _id: '$itemType',
                    quantity: { $sum: '$quantity' },
                    value: { $sum: { $multiply: ['$quantity', '$rate'] } }
                }}
            ]);
            reportData = reportData.map(d => ({ type: d._id, quantity: d.quantity, value: d.value }));
        }

        res.json({ kpis, reportData });

    } catch (err) {
        res.status(500).json({ msg: `Server Error in generating ${reportType} report.` });
    }
});

module.exports = router;