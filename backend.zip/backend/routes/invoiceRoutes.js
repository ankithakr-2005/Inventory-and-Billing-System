// axeyo-backend/routes/invoiceRoutes.js

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth'); 
const Invoice = require('../models/Invoice');
const Inventory = require('../models/Inventory');
const mongoose = require('mongoose');

// @route   POST /api/invoices - Save a new invoice AND deduct stock
router.post('/', auth, async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const invoiceData = req.body;
        
        // 1. Validate and Deduct Stock in a Transaction
        for (const item of invoiceData.items) {
            const inventoryItem = await Inventory.findOne({ itemName: item.particulars }).session(session);

            if (!inventoryItem) {
                await session.abortTransaction();
                session.endSession();
                return res.status(400).json({ msg: `Inventory item not found: ${item.particulars}` });
            }

            if (inventoryItem.quantity < item.quantity) {
                await session.abortTransaction();
                session.endSession();
                return res.status(400).json({ 
                    msg: `Insufficient stock for ${item.particulars}. Available: ${inventoryItem.quantity} M³.` 
                });
            }

            inventoryItem.quantity -= item.quantity;
            inventoryItem.lastUpdated = Date.now();
            await inventoryItem.save({ session });
        }

        // 2. Save the Invoice
        const newInvoice = new Invoice({ 
            ...invoiceData, 
            user: req.user.id 
        });

        const invoice = await newInvoice.save({ session });

        // 3. Commit the transaction
        await session.commitTransaction();
        session.endSession();
        
        res.status(201).json(invoice);

    } catch (err) {
        await session.abortTransaction();
        session.endSession();
        console.error(err.message);
        
        if (err.code === 11000) {
            return res.status(400).json({ msg: 'Duplicate Invoice Number. Please try again.' });
        }
        res.status(500).json({ msg: 'Server Error during invoice creation and stock deduction.' });
    }
});

// @route   GET /api/invoices - Get all invoices
router.get('/', auth, async (req, res) => {
    try {
        const invoices = await Invoice.find().sort({ invoiceDate: -1, invoiceNo: -1 });
        res.json(invoices);
    } catch (err) {
        res.status(500).send('Server Error');
    }
});

// @route   GET /api/invoices/:id - Get a single invoice by ID
router.get('/:id', auth, async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id); 

        if (!invoice) {
            return res.status(404).json({ msg: 'Invoice not found' });
        }
        res.json(invoice);

    } catch (err) {
        console.error(err.message); 
        res.status(500).send('Server Error (Invalid ID format or Database issue)');
    }
});

// ----------------------------------------------------------------------
// @route   DELETE /api/invoices/:id - Delete invoice AND REVERSE STOCK
// ----------------------------------------------------------------------
router.delete('/:id', auth, async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const invoiceId = req.params.id;

        // 1. Find the invoice to extract item details
        const invoice = await Invoice.findById(invoiceId).session(session);
        if (!invoice) {
            await session.abortTransaction();
            session.endSession();
            return res.status(404).json({ msg: 'Invoice not found' });
        }

        // 2. Reverse Stock for each item (ADD the quantity back)
        for (const item of invoice.items) {
            const inventoryItem = await Inventory.findOne({ itemName: item.particulars }).session(session);

            if (!inventoryItem) {
                // Critical failure: Abort if we cannot find the item to restock
                await session.abortTransaction();
                session.endSession();
                return res.status(400).json({ msg: `Failed to reverse stock: Item '${item.particulars}' not found in inventory.` });
            }

            // ADD the quantity back to inventory
            inventoryItem.quantity += item.quantity;
            inventoryItem.lastUpdated = Date.now();
            await inventoryItem.save({ session });
        }

        // 3. Delete the invoice record
        await Invoice.deleteOne({ _id: invoiceId }).session(session);
        
        // 4. Commit the transaction (deletion and restock happen atomically)
        await session.commitTransaction();
        session.endSession();

        res.json({ msg: 'Invoice successfully deleted and stock reversed.' });
        
    } catch (err) {
        await session.abortTransaction();
        session.endSession();
        console.error('Reversal Error:', err.message);
        res.status(500).send('Server Error during stock reversal process.');
    }
});


module.exports = router;