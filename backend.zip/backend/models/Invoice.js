// axeyo-backend/models/Invoice.js

const mongoose = require('mongoose');

const InvoiceItemSchema = new mongoose.Schema({
    particulars: { type: String, required: true },
    hsn: { type: String, default: '6802' },
    quantity: { type: Number, required: true },
    rate: { type: Number, required: true },
    amount: { type: Number, required: true },
});

const InvoiceSchema = new mongoose.Schema({
    // Header & Company Details
    invoiceNo: { type: String, required: true, unique: true },
    invoiceDate: { type: Date, required: true, default: Date.now },
    reserveChange: { type: String },
    
    // Buyer Details
    buyerName: { type: String, required: true },
    buyerAddress: { type: String, required: true },
    buyerState: { type: String },
    buyerStateCode: { type: String },
    buyerGST: { type: String },
    ewayBill: { type: String },

    // Shipping/Transport Details
    transportMode: { type: String },
    vehicleNo: { type: String },
    dateOfSupply: { type: Date },
    placeOfSupply: { type: String },
    consigneeName: { type: String },
    consigneeAddress: { type: String },
    consigneeState: { type: String },
    consigneeStateCode: { type: String },
    consigneeGSTIN: { type: String },
    
    // Line Items
    items: [InvoiceItemSchema],

    // Totals
    totalBeforeTax: { type: Number, required: true },
    cgstPercent: { type: Number, default: 9.00 },
    sgstPercent: { type: Number, default: 9.00 },
    cgstAmount: { type: Number, required: true },
    sgstAmount: { type: Number, required: true },
    grandTotal: { type: Number, required: true },
    amountInWords: { type: String, required: true },

    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }
}, { timestamps: true });

module.exports = mongoose.model('Invoice', InvoiceSchema);