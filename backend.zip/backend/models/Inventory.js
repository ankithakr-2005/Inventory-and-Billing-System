// axeyo-backend/models/Inventory.js

const mongoose = require('mongoose');

const InventorySchema = new mongoose.Schema({
    itemName: { 
        type: String, 
        required: true,
        trim: true,
        unique: true 
    },
    
    // --- UPDATED GRANITE SPECIFIC FIELDS ---
    itemColor: { // Maps to the new 'Color' input
        type: String, 
        required: true 
    },
    itemThickness: { // Maps to the new 'Thickness (mm)' input
        type: Number, 
        required: true,
        min: 1 
    },
    itemShape: { // Maps to the new 'Shape' select (Rectangular, Square, etc.)
        type: String, 
        required: true 
    },
    itemPolish: { // Maps to the new 'Surface Finish' select (Polished, Honed, etc.)
        type: String, 
        required: true 
    },
    // --- END UPDATED FIELDS ---

    quantity: { 
        type: Number, 
        required: true,
        min: 0, 
        default: 0
    },
    unit: { // Maps to the new 'itemUnit' select (M³, Sq. Ft., etc.)
        type: String,
        required: true
    },
    rate: { // Price per unit (₹)
        type: Number, 
        required: true,
        min: 0 
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    }
}, { timestamps: true });

module.exports = mongoose.model('Inventory', InventorySchema);